/**
 * Masters slice for managing masters data (timezones, etc.)
 * @module core/redux/mastersReducer
 * Uses Redux Toolkit's createSlice and createAsyncThunk for modern Redux patterns
 */

import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  getTimezone,
  getTitles,
  getCountries,
  getCurrencies,
  getStatesByCountry,
} from "@/core/services/mastersService";

/**
 * Initial state for masters slice.
 * @type {Object}
 */
const initialState = {
  timezones: [],
  timezonesLoading: false,
  timezonesError: null,
  jobTitles: [],
  jobTitlesLoading: false,
  jobTitlesError: null,
  countries: [],
  countriesLoading: false,
  countriesError: null,
  currencies: [],
  currenciesLoading: false,
  currenciesError: null,
  states: [],
  statesLoading: false,
  statesError: null,
};

/**
 * Async thunk for fetching timezones from API
 * @type {Function}
 * @returns {Promise} Promise that resolves with timezones data
 * @example
 * dispatch(fetchTimezones());
 */
export const fetchTimezones = createAsyncThunk(
  "masters/fetchTimezones",
  async (params = {}, { rejectWithValue }) => {
    try {
      const timezoneData = await getTimezone(params);
      //onsole.log("timezoneData", timezoneData);
      // Transform API response to match Select component format
      // Adjust transformation based on actual API response structure
      const formattedTimezones = Array.isArray(timezoneData.data)
        ? timezoneData.data.map((tz) => ({
            label: tz.label,
            value: tz.value,
          }))
        : [];

      return formattedTimezones;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data || error?.message || "Failed to fetch timezones"
      );
    }
  }
);

/**
 * Async thunk for fetching job titles from API
 * @type {Function}
 * @returns {Promise} Promise that resolves with job titles data
 * @example
 * dispatch(fetchJobTitles());
 */
export const fetchJobTitles = createAsyncThunk(
  "masters/fetchJobTitles",
  async (params = {}, { rejectWithValue }) => {
    try {
      const titlesData = await getTitles(params);

      // Transform API response to match Select component format
      // Adjust transformation based on actual API response structure

      const formattedTitles = Array.isArray(titlesData?.list)
        ? titlesData.list.map((title) => ({
            label: title.name,
            value: title._id,
          }))
        : [];

      return formattedTitles;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data || error?.message || "Failed to fetch job titles"
      );
    }
  }
);

/**
 * Async thunk for fetching countries from API
 * @type {Function}
 * @returns {Promise} Promise that resolves with countries data
 * @example
 * dispatch(fetchCountries());
 */
export const fetchCountries = createAsyncThunk(
  "masters/fetchCountries",
  async (params = {}, { rejectWithValue }) => {
    try {
      const countriesData = await getCountries(params);

      // Transform API response to match Select component format
      const formattedCountries = Array.isArray(countriesData?.list)
        ? countriesData.list.map((country) => ({
            label: country.name,
            value: country._id,
          }))
        : Array.isArray(countriesData?.data)
        ? countriesData.data.map((country) => ({
            label: country.name || country.label,
            value: country._id || country.value,
          }))
        : Array.isArray(countriesData)
        ? countriesData.map((country) => ({
            label: country.name || country.label,
            value: country._id || country.value,
          }))
        : [];

      return formattedCountries;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data || error?.message || "Failed to fetch countries"
      );
    }
  }
);

/**
 * Async thunk for fetching currencies from API
 * @type {Function}
 * @returns {Promise} Promise that resolves with currencies data
 * @example
 * dispatch(fetchCurrencies());
 */
export const fetchCurrencies = createAsyncThunk(
  "masters/fetchCurrencies",
  async (params = {}, { rejectWithValue }) => {
    try {
      const currenciesData = await getCurrencies(params);

      // Transform API response to match Select component format
      const formattedCurrencies = Array.isArray(currenciesData?.list)
        ? currenciesData.list.map((currency) => ({
            label: currency.name || currency.symbol,
            value: currency._id,
          }))
        : Array.isArray(currenciesData?.data)
        ? currenciesData.data.map((currency) => ({
            label: currency.name || currency.symbol || currency.label,
            value: currency._id || currency.value,
          }))
        : Array.isArray(currenciesData)
        ? currenciesData.map((currency) => ({
            label: currency.name || currency.symbol || currency.label,
            value: currency._id || currency.value,
          }))
        : [];

      return formattedCurrencies;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data || error?.message || "Failed to fetch currencies"
      );
    }
  }
);

/**
 * Async thunk for fetching states by country from API
 * @type {Function}
 * @returns {Promise} Promise that resolves with states data
 * @example
 * dispatch(fetchStatesByCountry({ countryId: "123" }));
 */
export const fetchStatesByCountry = createAsyncThunk(
  "masters/fetchStatesByCountry",
  async (params, { rejectWithValue }) => {
    try {
      const statesData = await getStatesByCountry(params);

      // Transform API response to match Select component format
      const formattedStates = Array.isArray(statesData?.list)
        ? statesData.list.map((state) => ({
            label: state.name,
            value: state._id,
          }))
        : [];

      return formattedStates;
    } catch (error) {
      return rejectWithValue(
        error?.response?.data || error?.message || "Failed to fetch states"
      );
    }
  }
);

/**
 * Masters slice using Redux Toolkit's createSlice
 * @type {Object}
 */
const mastersSlice = createSlice({
  name: "masters",
  initialState,
  reducers: {
    /**
     * Clear timezones error
     */
    clearTimezonesError: (state) => {
      state.timezonesError = null;
    },
    /**
     * Clear job titles error
     */
    clearJobTitlesError: (state) => {
      state.jobTitlesError = null;
    },
    /**
     * Clear countries error
     */
    clearCountriesError: (state) => {
      state.countriesError = null;
    },
    /**
     * Clear currencies error
     */
    clearCurrenciesError: (state) => {
      state.currenciesError = null;
    },
    /**
     * Clear states error
     */
    clearStatesError: (state) => {
      state.statesError = null;
    },
    /**
     * Clear states data (when country changes)
     */
    clearStates: (state) => {
      state.states = [];
      state.statesError = null;
    },
    /**
     * Reset masters state to initial
     */
    resetMasters: () => {
      return initialState;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch timezones - pending
      .addCase(fetchTimezones.pending, (state) => {
        state.timezonesLoading = true;
        state.timezonesError = null;
      })
      // Fetch timezones - fulfilled (success)
      .addCase(fetchTimezones.fulfilled, (state, action) => {
        state.timezonesLoading = false;
        state.timezones = action.payload;
        state.timezonesError = null;
      })
      // Fetch timezones - rejected (error)
      .addCase(fetchTimezones.rejected, (state, action) => {
        state.timezonesLoading = false;
        state.timezonesError = action.payload || action.error.message;
      })
      // Fetch job titles - pending
      .addCase(fetchJobTitles.pending, (state) => {
        state.jobTitlesLoading = true;
        state.jobTitlesError = null;
      })
      // Fetch job titles - fulfilled (success)
      .addCase(fetchJobTitles.fulfilled, (state, action) => {
        state.jobTitlesLoading = false;
        state.jobTitles = action.payload;
        state.jobTitlesError = null;
      })
      // Fetch job titles - rejected (error)
      .addCase(fetchJobTitles.rejected, (state, action) => {
        state.jobTitlesLoading = false;
        state.jobTitlesError = action.payload || action.error.message;
      })
      // Fetch countries - pending
      .addCase(fetchCountries.pending, (state) => {
        state.countriesLoading = true;
        state.countriesError = null;
      })
      // Fetch countries - fulfilled (success)
      .addCase(fetchCountries.fulfilled, (state, action) => {
        state.countriesLoading = false;
        state.countries = action.payload;
        state.countriesError = null;
      })
      // Fetch countries - rejected (error)
      .addCase(fetchCountries.rejected, (state, action) => {
        state.countriesLoading = false;
        state.countriesError = action.payload || action.error.message;
      })
      // Fetch currencies - pending
      .addCase(fetchCurrencies.pending, (state) => {
        state.currenciesLoading = true;
        state.currenciesError = null;
      })
      // Fetch currencies - fulfilled (success)
      .addCase(fetchCurrencies.fulfilled, (state, action) => {
        state.currenciesLoading = false;
        state.currencies = action.payload;
        state.currenciesError = null;
      })
      // Fetch currencies - rejected (error)
      .addCase(fetchCurrencies.rejected, (state, action) => {
        state.currenciesLoading = false;
        state.currenciesError = action.payload || action.error.message;
      })
      // Fetch states by country - pending
      .addCase(fetchStatesByCountry.pending, (state) => {
        state.statesLoading = true;
        state.statesError = null;
      })
      // Fetch states by country - fulfilled (success)
      .addCase(fetchStatesByCountry.fulfilled, (state, action) => {
        state.statesLoading = false;
        state.states = action.payload;
        state.statesError = null;
      })
      // Fetch states by country - rejected (error)
      .addCase(fetchStatesByCountry.rejected, (state, action) => {
        state.statesLoading = false;
        state.statesError = action.payload || action.error.message;
      });
  },
});

// Export actions
export const {
  clearTimezonesError,
  clearJobTitlesError,
  clearCountriesError,
  clearCurrenciesError,
  clearStatesError,
  clearStates,
  resetMasters,
} = mastersSlice.actions;

// Export reducer
export default mastersSlice.reducer;
