export const ApiPath = {
  userList: "/masters/user",
};
