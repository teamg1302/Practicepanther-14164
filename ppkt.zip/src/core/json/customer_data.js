export const CustomerData = [
  {
    id: 1,
    role: "Thomas",
    description: "Thomas",
  },
  {
    id: 2,
    role: "Rose",
    description: "Rose",
  },
  {
    id: 3,
    role: "Benjamin",
    description: "Benjamin",
  },
  {
    id: 4,
    role: "Kaitlin",
    description: "Kaitlin",
  },
  {
    id: 5,
    role: "Lilly",
    description: "Lilly",
  },
  {
    id: 6,
    role: "Freda",
    description: "Freda",
  },
  {
    id: 7,
    role: "Walk-in-Customer",
    description: "Walk-in-Customer",
  },
  {
    id: 8,
    role: "Maybelle",
    description: "Maybelle",
  },
  {
    id: 9,
    role: "Ellen",
    description: "Ellen",
  },
  {
    id: 10,
    role: "Walk-in-Customer",
    description: "Walk-in-Customer",
  },
];
