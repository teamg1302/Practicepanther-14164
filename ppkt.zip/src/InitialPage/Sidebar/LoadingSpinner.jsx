import React from "react";

export default function LoadingSpinner() {
    return (
        <div id="global-loader">
            <div className="whirly-loader"></div>
        </div>       
    );
}